// v1.1 - 21 kwiecien 2007

#include <stdio.h>
#include <stdlib.h>

void help(void)
{
 printf(" \"Alt Ctrl Delete\"  \n");
 printf("     Make Init\n");
 printf("       v1.1\n");
 
 
 printf("W celu utworzenia pliku startowego systemu - INIT.DAT, nalezy\n");
 printf("wprowadzic w wierszu polecenia nazwy plikow jako parametry.\n");
 printf("(pliki musza sie znajdowac w tym samym folderze co plik INIT.DAT\n");
 printf("i powinny byc skopiowane do glownego katalogu nosnika startowego\n");
 printf("systemu).\n");
 printf("Przyklad uzycia:\n\n");
 printf(" makeinit program1.bin program2.bin etc.\n");
}


int main (int argc, char *argv[])
{
 FILE *init=NULL;
 FILE *kand=NULL;
 int ilosc=0;
 int i;
 int dlugosc;
 int adres=0;
 char zero = 0;
  
 // Utworzenie nowego pliku
 init = fopen("INIT.DAT","w+");
 if (init == NULL)
    {
    printf("BLAD! Nie mozna utworzyc pliku INIT.DAT.\n");
    return 1;
    }
 
 // Tworzy INIT.DAT
 fseek(init,8,SEEK_SET);
 for(i=0; i<argc - 1; i++)
    {
    kand = NULL;
    kand = fopen(argv[i+1],"r");
    if (kand != NULL)
       {
       ilosc++;
       fseek(kand,0,SEEK_END);
       dlugosc = ftell(kand);
       fclose(kand);
          
       // zapis wpisu w init.dat
       fwrite(&adres,4,1,init);
       fwrite(&dlugosc,4,1,init);
       fprintf(init,"%s",argv[i+1]);
       fprintf(init,"%c",zero);
       }
    }
    
 // Zapis dlugosci pliku i ilosci dokonanych wpisow
 fseek(init,0,SEEK_END);
 dlugosc = ftell(init);
 fseek(init,0,SEEK_SET);
 fwrite(&dlugosc,4,1,init);
 fseek(init,4,SEEK_SET); 
 fwrite(&ilosc,4,1,init);
 
 fclose(init);
 return 0;
}
